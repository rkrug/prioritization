##' Routines for spatial prioritization for alien clearing
##' 
##' \tabular{ll}{
##' Package: \tab prioritization\cr
##' Type: \tab Package\cr
##' Version: \tab 0.0.1\cr
##' Date: \tab 2013-05-16_15-46\cr
##' License: \tab GPL (>= 2)\cr
##' LazyLoad: \tab yes\cr
##' }
##'
##' @docType package
##' @author Rainer M Krug \email{Rainer@@krugs.de}
NULL
